/**
 * 画廊浏览器 - Vue 3 前端
 * 仿 EhViewer 设计：画廊浏览、Webtoon 滚动阅读、搜索筛选、收藏标签
 */

const { createApp, ref, reactive, computed, onMounted, watch, nextTick, onUnmounted } = Vue;

// 取出需要的图标组件供模板使用
const Icons = ElementPlusIconsVue;
const {
  ArrowLeft, ArrowRight, Star, StarFilled, Refresh, Setting, Sort, PriceTag,
} = Icons;

const API_BASE = '';  // 同源

// 从 #app-template 读取模板
const APP_TEMPLATE = document.getElementById('app-template')?.innerHTML || '';

const App = {
  template: APP_TEMPLATE,
  setup() {
    // ============ 图标引用 ============
    // Vue 模板中只能访问 setup 返回对象中的属性
    const ArrowLeft = ElementPlusIconsVue.ArrowLeft;
    const ArrowRight = ElementPlusIconsVue.ArrowRight;
    const Star = ElementPlusIconsVue.Star;
    const StarFilled = ElementPlusIconsVue.StarFilled;
    const Refresh = ElementPlusIconsVue.Refresh;
    const Setting = ElementPlusIconsVue.Setting;
    const Sort = ElementPlusIconsVue.Sort;
    const PriceTag = ElementPlusIconsVue.PriceTag;

    // ============== 状态 ==============
    const searchKeyword = ref('');
    const viewMode = ref(localStorage.getItem('view_mode') || 'grid');
    const sort = ref(localStorage.getItem('sort') || 'updated_desc');
    const filterFavorite = ref(false);
    const selectedTags = ref([]);
    const page = ref(1);
    const pageSize = 24;
    const total = ref(0);

    const galleries = ref([]);
    const tags = ref([]);
    const categories = ref([]);  // 分类列表
    const selectedCategory = ref('');  // 当前选中的分类（空=全部）
    const stats = ref(null);
    const loading = ref(false);

    const galleryVisible = ref(false);
    const currentGallery = ref(null);
    const currentPage = ref(0);
    const dialogFullscreen = ref(true);
    const readMode = ref(localStorage.getItem('read_mode') || 'scroll');
    const readEnd = ref(false);
    const scrollReader = ref(null);
    const loadedImages = ref(new Set());
    const saveProgressTimer = ref(null);

    const showSettings = ref(false);
    const sidebarOpen = ref(false); // 移动端侧边栏抽屉开关
    const settingsTab = ref('scan');
    const cfg = reactive({
      scan_dirs: [],
      thumbnail_size: 320,
      image_quality: 'high',
      read_mode: 'scroll',
      theme: 'auto',
    });
    const newScanDir = ref('');
    const scanDirs = ref([]);

    const scanRunning = ref(false);
    const scanStatus = ref(null);
    const showScanProgress = ref(false);
    const scanPollTimer = ref(null);

    const showTagManager = ref(false);
    const newTagName = ref('');

    // ============== 计算属性 ==============
    const progressPercent = computed(() => {
      if (!currentGallery.value) return 0;
      return Math.round((currentPage.value + 1) * 100 / currentGallery.value.page_count);
    });

    // 进度条 mark（仅在页数较少时显示起止刻度）
    const pageMarks = computed(() => {
      if (!currentGallery.value) return {};
      const total = currentGallery.value.page_count;
      if (total <= 20) {
        // 间隔显示，避免拥挤
        const step = Math.max(1, Math.floor(total / 5));
        const marks = {};
        for (let i = 0; i < total; i += step) {
          marks[i] = (i + 1).toString();
        }
        if (!marks[total - 1]) marks[total - 1] = total.toString();
        return marks;
      }
      return {
        0: '1',
        [total - 1]: total.toString(),
      };
    });

    // 滑块拖拽中的实时处理（只更新预览，不保存、不跳转）
    let isUserSliding = false;
    function onSliderInput(val) {
      isUserSliding = true;
      currentPage.value = val;
    }

    // 滑块拖拽结束，跳转
    function onSliderChange(val) {
      isUserSliding = false;
      jumpToPage(val);
    }

    // 跳转到指定页
    function jumpToPage(page) {
      if (!currentGallery.value) return;
      page = Math.max(0, Math.min(currentGallery.value.page_count - 1, page));
      currentPage.value = page;
      if (readMode.value === 'scroll') {
        nextTick(() => scrollToPage(page));
      }
      scheduleSaveProgress();
      if (page >= currentGallery.value.page_count - 1) {
        readEnd.value = true;
      }
    }

    // ============ 沉浸阅读模式 ============
    const uiVisible = ref(true);  // 控制工具栏和进度条显示
    const showImmersiveHint = ref(false);  // 首次进入提示
    let hideTimer = null;
    let hintShownThisSession = false;

    function showUI() {
      uiVisible.value = true;
      // 重置隐藏计时器
      if (hideTimer) clearTimeout(hideTimer);
      // 3秒后自动隐藏
      hideTimer = setTimeout(() => {
        if (galleryVisible.value) {
          uiVisible.value = false;
        }
      }, 3000);
    }

    function toggleUI() {
      if (hideTimer) clearTimeout(hideTimer);
      uiVisible.value = !uiVisible.value;
      if (uiVisible.value) showUI();
    }

    function onReaderMouseMove() {
      if (!galleryVisible.value) return;
      showUI();
      // 首次显示提示
      if (!hintShownThisSession) {
        hintShownThisSession = true;
        showImmersiveHint.value = true;
        setTimeout(() => { showImmersiveHint.value = false; }, 4000);
      }
    }

    // 打开画廊时启动沉浸模式
    const _originalOpenGallery = openGallery;
    // 重新定义以在打开时启动隐藏计时器
    async function openGalleryWithImmersive(gid) {
      await _originalOpenGallery(gid);
      hintShownThisSession = false;
      // 延迟启动隐藏，让用户看到初始 UI
      setTimeout(() => showUI(), 500);
    }
    // 关闭画廊时清理
    function cleanupImmersive() {
      if (hideTimer) clearTimeout(hideTimer);
      uiVisible.value = true;
    }

    const pagedVisibleImages = computed(() => {
      if (!currentGallery.value) return [];
      const imgs = currentGallery.value.images;
      if (readMode.value === 'single') {
        return [imgs[currentPage.value]].filter(Boolean);
      } else if (readMode.value === 'double') {
        return [imgs[currentPage.value], imgs[currentPage.value + 1]].filter(Boolean);
      }
      return [];
    });

    // ============== API 调用 ==============
    async function api(url, opts = {}) {
      const ctrl = new AbortController();
      const timeout = setTimeout(() => ctrl.abort(), 30000);  // 30s 超时保护
      opts.signal = ctrl.signal;
      try {
        const res = await fetch(API_BASE + url, opts);
        if (!res.ok) throw new Error(`API ${url} -> ${res.status}`);
        return await res.json();
      } finally {
        clearTimeout(timeout);
      }
    }

    async function loadGalleries() {
      loading.value = true;
      try {
        const params = new URLSearchParams({
          page: page.value,
          page_size: pageSize,
          sort: sort.value,
        });
        if (searchKeyword.value) params.set('q', searchKeyword.value);
        if (filterFavorite.value) params.set('favorite', 'true');
        if (selectedCategory.value) params.set('category', selectedCategory.value);
        selectedTags.value.forEach(t => params.append('tag', t));

        const data = await api('/api/galleries?' + params);
        galleries.value = data.items;
        total.value = data.total;
      } catch (e) {
        ElementPlus.ElMessage.error('加载失败: ' + e.message);
      } finally {
        loading.value = false;
      }
    }

    async function loadTags() {
      try {
        tags.value = await api('/api/tags');
      } catch (e) { /* ignore */ }
    }

    async function loadCategories() {
      try {
        const data = await api('/api/categories');
        categories.value = data.items || [];
      } catch (e) { /* ignore */ }
    }

    async function loadStats() {
      try {
        stats.value = await api('/api/stats');
      } catch (e) { /* ignore */ }
    }

    async function loadConfig() {
      try {
        const c = await api('/api/config');
        Object.assign(cfg, c);
        scanDirs.value = c.scan_dirs || [];
      } catch (e) { /* ignore */ }
    }

    // ============== 交互 ==============
    function handleSearch() {
      page.value = 1;
      loadGalleries();
    }

    function selectCategory(name) {
      selectedCategory.value = selectedCategory.value === name ? '' : name;
      page.value = 1;
      loadGalleries();
    }

    function toggleTag(name) {
      const i = selectedTags.value.indexOf(name);
      if (i >= 0) selectedTags.value.splice(i, 1);
      else selectedTags.value.push(name);
      page.value = 1;
      loadGalleries();
    }

    function toggleSidebar() {
      sidebarOpen.value = !sidebarOpen.value;
    }

    // ============== 触摸手势 ==============
    let touchStartX = 0;
    let touchStartY = 0;
    let touchStartTime = 0;
    let touchEndX = 0;
    let touchEndY = 0;

    function onTouchStart(e) {
      if (e.touches.length !== 1) return;
      const touch = e.touches[0];
      touchStartX = touch.clientX;
      touchStartY = touch.clientY;
      touchStartTime = Date.now();
    }

    function onTouchEnd(e) {
      if (!currentGallery.value) return;
      const dx = touchEndX - touchStartX;
      const dy = touchEndY - touchStartY;
      const dt = Date.now() - touchStartTime;
      if (dt > 500) return;
      const absX = Math.abs(dx);
      const absY = Math.abs(dy);
      if (Math.max(absX, absY) < 50) return;
      // 左右滑动翻页（非滚动模式）
      if (readMode.value !== 'scroll' && absX > absY && absX > 80) {
        if (dx < 0) nextPage();
        else prevPage();
        e.preventDefault?.();
      }
      // 左右滑动控制侧边栏（不在阅读时）
      if (!galleryVisible.value && absX > absY && absX > 60 && absY < 40) {
        if (dx < 0 && sidebarOpen.value) sidebarOpen.value = false;
        else if (dx > 0 && !sidebarOpen.value) toggleSidebar();
      }
    }

    function onTouchMove(e) {
      if (e.touches.length === 1) {
        touchEndX = e.touches[0].clientX;
        touchEndY = e.touches[0].clientY;
      }
    }

    // 双击切换工具栏
    function onReaderDoubleClick() {
      if (galleryVisible.value && currentGallery.value) {
        toggleUI();
      }
    }

    function onSortChange(cmd) {
      sort.value = cmd;
      localStorage.setItem('sort', cmd);
      loadGalleries();
    }

    watch(filterFavorite, () => { page.value = 1; loadGalleries(); });
    watch(viewMode, v => localStorage.setItem('view_mode', v));

    function goHome() {
      searchKeyword.value = '';
      selectedTags.value = [];
      filterFavorite.value = false;
      selectedCategory.value = '';
      page.value = 1;
      loadGalleries();
    }

    async function openGallery(gid) {
      try {
        const data = await api(`/api/galleries/${gid}`);
        currentGallery.value = data;
        currentPage.value = data.last_read_page || 0;
        readEnd.value = false;
        loadedImages.value = new Set();
        galleryVisible.value = true;
        await nextTick();
        // 滚动模式：跳转到上次阅读位置
        if (readMode.value === 'scroll') {
          await nextTick();
          scrollToPage(currentPage.value);
        }
        loadStats(); // 更新最近浏览
      } catch (e) {
        ElementPlus.ElMessage.error('打开失败: ' + e.message);
      }
    }

    function closeGallery() {
      if (hideTimer) clearTimeout(hideTimer);
      uiVisible.value = true;
      showImmersiveHint.value = false;
      galleryVisible.value = false;
      currentGallery.value = null;
      currentPage.value = 0;
      readEnd.value = false;
      // 不重新加载列表：当前 galleries 数组仍然有效，重加载反而可能引起 race condition
      // loadGalleries();
    }

    function onGalleryClose() {
      // 保存阅读进度
      if (currentGallery.value) {
        api(`/api/galleries/${currentGallery.value.id}/progress`, {
          method: 'POST',
          headers: {'Content-Type': 'application/json'},
          body: JSON.stringify({page: currentPage.value})
        }).catch(() => {});
      }
    }

    function onGalleryClosed() {
      // dialog 关闭动画结束后（@closed 触发），立即禁用残留 overlay 的点击拦截，
      // 避免 el-overlay 关闭动画期间（~300ms）阻止用户操作 header 等按钮。
      requestAnimationFrame(() => {
        document.querySelectorAll('.el-overlay').forEach(ov => {
          if (!ov.querySelector('.reader-dialog, .el-dialog')) {
            ov.style.pointerEvents = 'none';
          }
        });
      });
    }

    function toggleFullscreen() {
      dialogFullscreen.value = !dialogFullscreen.value;
    }

    function onModeChange(mode) {
      localStorage.setItem('read_mode', mode);
      if (mode === 'scroll') {
        nextTick(() => scrollToPage(currentPage.value));
      }
    }

    // 滚动阅读：图片加载时更新当前页
    function onImageLoad(idx) {
      loadedImages.value.add(idx);
      // 计算当前可见页
      if (readMode.value === 'scroll' && scrollReader.value) {
        const pages = scrollReader.value.querySelectorAll('.scroll-page');
        const readerTop = scrollReader.value.getBoundingClientRect().top;
        let nearestIdx = currentPage.value;
        let nearestDist = Infinity;
        pages.forEach((p, i) => {
          const rect = p.getBoundingClientRect();
          const dist = Math.abs(rect.top - readerTop - 100);
          if (rect.bottom > readerTop && rect.top < readerTop + window.innerHeight) {
            if (dist < nearestDist) {
              nearestDist = dist;
              nearestIdx = i;
            }
          }
        });
        if (nearestIdx !== currentPage.value) {
          currentPage.value = nearestIdx;
          scheduleSaveProgress();
          if (nearestIdx === currentGallery.value.page_count - 1) {
            readEnd.value = true;
          }
        }
      }
    }

    function scrollToPage(idx) {
      if (!scrollReader.value) return;
      const pages = scrollReader.value.querySelectorAll('.scroll-page');
      if (pages[idx]) {
        pages[idx].scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    }

    function prevPage() {
      if (currentPage.value > 0) {
        currentPage.value -= (readMode.value === 'double' ? 2 : 1);
        scheduleSaveProgress();
      }
    }

    function nextPage() {
      if (!currentGallery.value) return;
      const max = currentGallery.value.page_count - (readMode.value === 'double' ? 2 : 1);
      if (currentPage.value < max) {
        currentPage.value += (readMode.value === 'double' ? 2 : 1);
        scheduleSaveProgress();
        if (currentPage.value >= currentGallery.value.page_count - 1) {
          readEnd.value = true;
        }
      }
    }

    function scheduleSaveProgress() {
      clearTimeout(saveProgressTimer.value);
      saveProgressTimer.value = setTimeout(() => {
        if (currentGallery.value) {
          api(`/api/galleries/${currentGallery.value.id}/progress`, {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({page: currentPage.value})
          }).catch(() => {});
        }
      }, 1500);
    }

    async function toggleFavorite() {
      if (!currentGallery.value) return;
      try {
        const r = await api(`/api/galleries/${currentGallery.value.id}/favorite`, {method: 'POST'});
        currentGallery.value.is_favorite = r.is_favorite;
        ElementPlus.ElMessage.success(r.is_favorite ? '已收藏' : '已取消收藏');
      } catch (e) {
        ElementPlus.ElMessage.error('操作失败');
      }
    }

    // 标签管理
    async function addTagToGallery() {
      if (!newTagName.value.trim() || !currentGallery.value) return;
      try {
        await api(`/api/galleries/${currentGallery.value.id}/tags`, {
          method: 'POST',
          headers: {'Content-Type': 'application/json'},
          body: JSON.stringify({name: newTagName.value.trim()})
        });
        // 重新加载画廊
        const data = await api(`/api/galleries/${currentGallery.value.id}`);
        currentGallery.value = data;
        newTagName.value = '';
        loadTags();
        ElementPlus.ElMessage.success('标签已添加');
      } catch (e) {
        ElementPlus.ElMessage.error('添加失败');
      }
    }

    async function quickAddTag(name) {
      newTagName.value = name;
      await addTagToGallery();
    }

    async function removeTagFromGallery(tid) {
      if (!currentGallery.value) return;
      try {
        await api(`/api/galleries/${currentGallery.value.id}/tags/${tid}`, {method: 'DELETE'});
        const data = await api(`/api/galleries/${currentGallery.value.id}`);
        currentGallery.value = data;
        loadTags();
      } catch (e) {
        ElementPlus.ElMessage.error('移除失败');
      }
    }

    // 扫描
    async function triggerScan() {
      if (scanRunning.value) return;
      if (!scanDirs.value.length) {
        ElementPlus.ElMessage.warning('请先在设置中添加扫描目录');
        showSettings.value = true;
        return;
      }
      try {
        const r = await api('/api/scan', {
          method: 'POST',
          headers: {'Content-Type': 'application/json'},
          body: JSON.stringify({scan_dirs: scanDirs.value})
        });
        // 检查后端返回的诊断信息
        if (!r.ok) {
          // 显示诊断详情 + 授权指引
          const diagHtml = (r.diagnostics || []).map(d => {
            const isPerm = d.status === 'no_permission' || d.status === 'permission_error';
            const bg = isPerm ? '#fef2f2' : '#fff7e6';
            const color = isPerm ? '#dc2626' : '#d97706';
            return `<div style="margin: 8px 0; padding: 8px; background: ${bg}; border-radius: 4px; border-left: 3px solid ${color};">
              <b style="color: ${color};">${d.path}</b><br>
              <span style="color: ${color};">${d.msg}</span>
            </div>`;
          }).join('');
          // 检查是否需要授权
          const needAuth = (r.diagnostics || []).some(d =>
            d.status === 'no_permission' || d.status === 'permission_error'
          );
          const authTip = needAuth ? `
            <div style="margin-top: 16px; padding: 12px; background: #ecfdf5; border-radius: 6px; border-left: 3px solid #10b981;">
              <b style="color: #059669;">如何授权访问目录？</b><br>
              <ol style="margin: 8px 0 0 0; padding-left: 20px; color: #047857;">
                <li>进入 fnOS 【应用中心】</li>
                <li>找到【画廊浏览器】</li>
                <li>点击【设置】或【授权】</li>
                <li>添加需要扫描的目录并设为【读写】</li>
                <li>返回应用重试扫描</li>
              </ol>
            </div>` : '';
          ElementPlus.ElMessageBox.alert(
            `<div style="max-height: 400px; overflow-y: auto;">扫描目录验证失败：<br>${diagHtml}${authTip}</div>`,
            '无法扫描',
            {
              dangerouslyUseHTMLString: true,
              confirmButtonText: '我知道了',
            }
          );
          return;
        }
        // 有诊断信息但是成功，也提示一下
        if (r.diagnostics && r.diagnostics.length > 0) {
          const warnDirs = r.diagnostics.filter(d => d.status !== 'ok');
          if (warnDirs.length > 0) {
            const warnHtml = warnDirs.map(d =>
              `<div style="margin: 4px 0;"><b>${d.path}</b>: <span style="color: #d97706;">${d.msg}</span></div>`
            ).join('');
            ElementPlus.ElMessageBox.alert(
              `<div>部分目录未能扫描：<br>${warnHtml}<br><small>可在 fnOS【应用设置】中授权访问。</small></div>`,
              '提示',
              {
                dangerouslyUseHTMLString: true,
                confirmButtonText: '继续',
              }
            );
          }
        }
        scanRunning.value = true;
        showScanProgress.value = true;
        pollScanStatus();
      } catch (e) {
        ElementPlus.ElMessage.error('扫描启动失败: ' + e.message);
      }
    }

    async function pollScanStatus() {
      try {
        scanStatus.value = await api('/api/scan/status');
        if (scanStatus.value.running) {
          scanPollTimer.value = setTimeout(pollScanStatus, 1000);
        } else {
          scanRunning.value = false;
          ElementPlus.ElMessage.success('扫描完成');
          showScanProgress.value = false;
          loadGalleries();
          loadStats();
          loadTags();
          loadCategories();
        }
      } catch (e) {
        scanRunning.value = false;
      }
    }

    function addScanDir() {
      const d = newScanDir.value.trim();
      if (!d) return;
      if (!scanDirs.value.includes(d)) {
        scanDirs.value.push(d);
        newScanDir.value = '';
      }
    }

    function removeScanDir(i) {
      scanDirs.value.splice(i, 1);
    }

    async function saveConfig() {
      cfg.scan_dirs = scanDirs.value;
      try {
        await api('/api/config', {
          method: 'POST',
          headers: {'Content-Type': 'application/json'},
          body: JSON.stringify(cfg)
        });
        // 同时保存扫描目录
        await api('/api/scan/dirs', {
          method: 'POST',
          headers: {'Content-Type': 'application/json'},
          body: JSON.stringify({scan_dirs: scanDirs.value})
        });
        ElementPlus.ElMessage.success('设置已保存');
      } catch (e) {
        ElementPlus.ElMessage.error('保存失败');
      }
    }

    function formatSize(bytes) {
      if (!bytes) return '0 B';
      const units = ['B', 'KB', 'MB', 'GB', 'TB'];
      let i = 0;
      while (bytes >= 1024 && i < units.length - 1) {
        bytes /= 1024;
        i++;
      }
      return `${bytes.toFixed(i === 0 ? 0 : 1)} ${units[i]}`;
    }

    // 键盘快捷键
    function handleKeydown(e) {
      if (!galleryVisible.value) return;
      if (e.key === 'ArrowLeft' && readMode.value !== 'scroll') prevPage();
      else if (e.key === 'ArrowRight' && readMode.value !== 'scroll') nextPage();
      else if (e.key === 'Escape') closeGallery();
      else if (e.key === 'h' || e.key === 'H') toggleUI();
      else if (e.key === 'f' || e.key === 'F') toggleFullscreen();
    }

    onMounted(async () => {
      await loadConfig();
      await loadGalleries();
      await loadTags();
      await loadCategories();
      await loadStats();
      window.addEventListener('keydown', handleKeydown);
      // 全局触摸事件（侧边栏滑动控制）
      window.addEventListener('touchstart', onTouchStart, { passive: true });
      window.addEventListener('touchmove', onTouchMove, { passive: true });
      window.addEventListener('touchend', onTouchEnd, { passive: false });
    });

    onUnmounted(() => {
      window.removeEventListener('keydown', handleKeydown);
      window.removeEventListener('touchstart', onTouchStart);
      window.removeEventListener('touchmove', onTouchMove);
      window.removeEventListener('touchend', onTouchEnd);
      clearTimeout(saveProgressTimer.value);
      clearTimeout(scanPollTimer.value);
    });

    return {
      // state
      searchKeyword, viewMode, sort, filterFavorite, selectedTags,
      page, pageSize, total, galleries, tags, stats, loading,
      galleryVisible, currentGallery, currentPage, dialogFullscreen, readMode,
      readEnd, scrollReader, loadedImages,
      showSettings, settingsTab, cfg, newScanDir, scanDirs,
      scanRunning, scanStatus, showScanProgress,
      showTagManager, newTagName,
      uiVisible, showImmersiveHint,
      sidebarOpen,
      // computed
      progressPercent, pagedVisibleImages, pageMarks,
      // methods
      handleSearch, toggleTag, onSortChange, goHome,
      openGallery: openGalleryWithImmersive, closeGallery, onGalleryClose, toggleFullscreen, onModeChange, toggleSidebar, onReaderDoubleClick,
      onImageLoad, scrollToPage, prevPage, nextPage, toggleFavorite,
      onSliderInput, onSliderChange, jumpToPage,
      onReaderMouseMove, toggleUI, cleanupImmersive,
      addTagToGallery, quickAddTag, removeTagFromGallery,
      triggerScan, addScanDir, removeScanDir, saveConfig, formatSize,
      loadGalleries, loadStats, loadTags, loadCategories,
      categories, selectedCategory, selectCategory,
      // icons
      ArrowLeft, ArrowRight, Star, StarFilled, Refresh, Setting, Sort, PriceTag,
    };
  },
};

const app = createApp(App);
app.use(ElementPlus, { locale: ElementPlusLocaleZhCn });
for (const [key, comp] of Object.entries(ElementPlusIconsVue)) {
  // 同时注册 PascalCase 和 kebab-case 别名，避免模板中大小写匹配失败
  app.component(key, comp);
  const kebab = key.replace(/([a-z0-9])([A-Z])/g, '$1-$2').toLowerCase();
  app.component(kebab, comp);
}
app.mount('#app');