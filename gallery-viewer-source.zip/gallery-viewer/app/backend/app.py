"""
画廊浏览器后端
仿 EhViewer 设计：画廊浏览、Webtoon 滚动阅读、搜索筛选、收藏标签
"""
import os
import io
import json
import time
import sqlite3
import argparse
import hashlib
import threading
from pathlib import Path
from datetime import datetime
from contextlib import closing

from flask import Flask, request, jsonify, send_file, send_from_directory, abort
from flask_cors import CORS
from PIL import Image

# ============== 参数解析 ==============
parser = argparse.ArgumentParser()
parser.add_argument("--host", default="0.0.0.0")
parser.add_argument("--port", type=int, default=8899)
parser.add_argument("--db", default="/tmp/gallery.db")
parser.add_argument("--config", default="/tmp/config.json")
parser.add_argument("--thumb-cache", default="/tmp/thumb_cache")
parser.add_argument("--ui-dir", default=os.path.join(os.path.dirname(os.path.abspath(__file__)), "static"))
args = parser.parse_args()

UI_DIR = args.ui_dir

# ============== 全局 ==============
app = Flask(__name__, static_folder=None)
CORS(app)
DB_PATH = args.db
CONFIG_PATH = args.config
THUMB_CACHE = Path(args.thumb_cache)
THUMB_CACHE.mkdir(parents=True, exist_ok=True)

SUPPORTED_EXTS = {".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp", ".tiff"}
SCAN_LOCK = threading.Lock()
SCAN_STATUS = {"running": False, "current": "", "scanned": 0, "total": 0, "started_at": None}


def load_config():
    if os.path.exists(CONFIG_PATH):
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    return {
        "scan_dirs": [],
        "thumbnail_size": 320,
        "image_quality": "high",
        "read_mode": "scroll",
        "theme": "auto",
        "language": "zh-CN",
        "max_thumb_cache_mb": 1024,
    }


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    """初始化数据库表"""
    with closing(get_db()) as db:
        db.executescript(_INIT_SQL)

        # 迁移：给已有数据库加 category 字段
        cols = [r[1] for r in db.execute("PRAGMA table_info(galleries)").fetchall()]
        if "category" not in cols:
            db.execute("ALTER TABLE galleries ADD COLUMN category TEXT DEFAULT ''")
            db.execute("CREATE INDEX IF NOT EXISTS idx_galleries_category ON galleries(category)")

        db.commit()


_INIT_SQL = """
CREATE TABLE IF NOT EXISTS galleries (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    path TEXT UNIQUE NOT NULL,
    cover TEXT,
    page_count INTEGER DEFAULT 0,
    file_size INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    description TEXT,
    rating REAL DEFAULT 0,
    view_count INTEGER DEFAULT 0,
    is_favorite INTEGER DEFAULT 0,
    last_read_page INTEGER DEFAULT 0,
    last_read_at TIMESTAMP,
    category TEXT DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_galleries_category ON galleries(category);

CREATE TABLE IF NOT EXISTS gallery_images (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    gallery_id INTEGER NOT NULL,
    page_index INTEGER NOT NULL,
    file_path TEXT NOT NULL,
    file_name TEXT NOT NULL,
    file_size INTEGER DEFAULT 0,
    width INTEGER DEFAULT 0,
    height INTEGER DEFAULT 0,
    FOREIGN KEY (gallery_id) REFERENCES galleries(id) ON DELETE CASCADE,
    UNIQUE(gallery_id, page_index)
);

CREATE TABLE IF NOT EXISTS tags (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE NOT NULL,
    color TEXT DEFAULT '#1976d2',
    use_count INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS gallery_tags (
    gallery_id INTEGER NOT NULL,
    tag_id INTEGER NOT NULL,
    PRIMARY KEY (gallery_id, tag_id),
    FOREIGN KEY (gallery_id) REFERENCES galleries(id) ON DELETE CASCADE,
    FOREIGN KEY (tag_id) REFERENCES tags(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_galleries_favorite ON galleries(is_favorite);
CREATE INDEX IF NOT EXISTS idx_galleries_updated ON galleries(updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_gallery_images_gallery ON gallery_images(gallery_id);
CREATE INDEX IF NOT EXISTS idx_tags_name ON tags(name);

CREATE VIRTUAL TABLE IF NOT EXISTS galleries_fts USING fts5(
    title, description, content='galleries', content_rowid='id'
);

INSERT OR IGNORE INTO galleries_fts(galleries_fts) VALUES('rebuild');

CREATE TRIGGER IF NOT EXISTS galleries_fts_ai AFTER INSERT ON galleries BEGIN
    INSERT INTO galleries_fts(rowid, title, description)
    VALUES (new.id, new.title, COALESCE(new.description, ''));
END;
CREATE TRIGGER IF NOT EXISTS galleries_fts_ad AFTER DELETE ON galleries BEGIN
    INSERT INTO galleries_fts(galleries_fts, rowid, title, description)
    VALUES('delete', old.id, old.title, COALESCE(old.description, ''));
END;
CREATE TRIGGER IF NOT EXISTS galleries_fts_au AFTER UPDATE ON galleries BEGIN
    INSERT INTO galleries_fts(galleries_fts, rowid, title, description)
    VALUES('delete', old.id, old.title, COALESCE(old.description, ''));
    INSERT INTO galleries_fts(rowid, title, description)
    VALUES (new.id, new.title, COALESCE(new.description, ''));
END;
"""


# ============== 工具函数 ==============
def natural_key(s):
    """自然排序：图片1.jpg < 图片2.jpg < 图片10.jpg"""
    import re
    return [int(t) if t.isdigit() else t.lower() for t in re.split(r"(\d+)", str(s))]


def get_image_info(path):
    try:
        with Image.open(path) as im:
            return im.size
    except Exception:
        return (0, 0)


def make_thumbnail(src_path, thumb_path, size=320, quality=85, static_only=False):
    """生成缩略图（带缓存）。
    static_only=True: 动画 GIF/WebP 只取第一帧转静态 JPEG（用于封面）。"""
    if os.path.exists(thumb_path):
        mtime = os.path.getmtime(thumb_path)
        if mtime >= os.path.getmtime(src_path):
            return  # 缓存有效

    try:
        with Image.open(src_path) as im:
            ext = Path(src_path).suffix.lower()
            is_animated = getattr(im, "is_animated", False) or getattr(im, "n_frames", 1) > 1
            im.thumbnail((size, size * 4), Image.LANCZOS)

            # 动画 GIF/WebP → 保留动画另存为 WebP（不转 RGB 保留多帧）
            # static_only=True（封面场景）→ 强制转静态
            if is_animated and ext in (".gif", ".webp") and not static_only:
                thumb_webp = str(thumb_path).rsplit(".", 1)[0] + ".webp"
                try:
                    # 收集所有帧的 duration 和 loop
                    durations = []
                    n_frames = getattr(im, "n_frames", 1)
                    for frame_idx in range(n_frames):
                        im.seek(frame_idx)
                        durations.append(im.info.get("duration", 100))
                    loop = im.info.get("loop", 0)
                    im.seek(0)

                    # 缩放所有帧（缩略图不需要原尺寸）
                    scaled_frames = []
                    target_size = im.size
                    # 计算缩放后尺寸
                    from PIL import Image as _I
                    w, h = im.size
                    if w > size or h > size * 4:
                        ratio = min(size / w, size * 4 / h)
                        new_w, new_h = int(w * ratio), int(h * ratio)
                    else:
                        new_w, new_h = w, h
                    for frame_idx in range(n_frames):
                        im.seek(frame_idx)
                        fr = im.copy()
                        fr = fr.resize((new_w, new_h), _I.LANCZOS)
                        if fr.mode == "P":
                            fr = fr.convert("RGB")
                        scaled_frames.append(fr)

                    scaled_frames[0].save(
                        thumb_webp, "WEBP", save_all=True,
                        append_images=scaled_frames[1:],
                        duration=durations, loop=loop, quality=quality,
                        lossless=False,
                    )
                    return
                except Exception as e:
                    app.logger.warning(f"动画缩略图失败 {src_path}: {e}")
                    # Fallback：仅第一帧转 JPEG
                    try:
                        im.seek(0)
                    except Exception:
                        pass
                    if im.mode in ("RGBA", "P"):
                        im = im.convert("RGB")
                    im.save(thumb_path, "JPEG", quality=quality, optimize=True)
                    return

            # 静态图片 → JPEG
            if im.mode in ("RGBA", "P"):
                im = im.convert("RGB")
            im.save(thumb_path, "JPEG", quality=quality, optimize=True)
    except Exception as e:
        app.logger.warning(f"缩略图失败 {src_path}: {e}")


def get_thumb_path(src_path, size=320):
    """获取缩略图缓存路径"""
    file_hash = hashlib.md5(src_path.encode("utf-8")).hexdigest()[:16]
    sub = THUMB_CACHE / file_hash[:2]
    sub.mkdir(exist_ok=True)
    ext = Path(src_path).suffix.lower()
    # 动画格式 → .webp 后缀
    if ext in (".gif", ".webp"):
        return sub / f"{file_hash}_{size}.webp"
    return sub / f"{file_hash}_{size}.jpg"


# ============== 扫描相关 ==============
def scan_gallery(gallery_path):
    """扫描单个文件夹作为画廊"""
    gallery_path = Path(gallery_path)
    if not gallery_path.is_dir():
        return None

    images = []
    total_size = 0
    for f in sorted(gallery_path.iterdir(), key=natural_key):
        if f.is_file() and f.suffix.lower() in SUPPORTED_EXTS:
            images.append(f)
            try:
                total_size += f.stat().st_size
            except OSError:
                pass

    if not images:
        return None

    title = gallery_path.name
    cover = str(images[0]) if images else None

    return {
        "title": title,
        "path": str(gallery_path),
        "cover": cover,
        "page_count": len(images),
        "file_size": total_size,
        "images": images,
    }


def do_scan(scan_dirs, progress_callback=None):
    """执行扫描"""
    SCAN_STATUS.update({
        "running": True,
        "current": "",
        "scanned": 0,
        "total": 0,
        "started_at": datetime.now().isoformat(),
    })

    try:
        # 收集所有候选画廊：递归扫描所有子文件夹
        # 分类规则：画廊 category = 其直接父级扫描根目录的"顶级分类名"
        # 顶级分类 = 扫描根目录本身 OR 根目录下的一级子目录
        candidates = []  # (gallery_path, category_name, scan_root_name)
        for scan_dir in scan_dirs:
            scan_dir = Path(scan_dir)
            if not scan_dir.is_dir():
                continue
            scan_root_name = scan_dir.name  # 顶级分类名 = 扫描根目录名

            # 1. 扫描根目录自身作为画廊（如果有图片）
            candidates.append((scan_dir, "", scan_root_name))

            # 2. 递归扫描所有子文件夹作为画廊
            for sub in sorted(scan_dir.rglob("*")):
                if sub.is_dir():
                    # 计算相对路径：取直接父级目录
                    try:
                        rel = sub.relative_to(scan_dir)
                        parts = rel.parts
                        if len(parts) == 0:
                            continue  # 根目录，已经处理
                        # category = 顶级（一级）目录名；空时用扫描根目录名
                        category = parts[0] if len(parts) >= 1 else scan_root_name
                        # 跳过包含图片的子目录（因为它们会作为画廊本身被处理）
                        candidates.append((sub, category, scan_root_name))
                    except ValueError:
                        continue

        # 去重（按 path）
        seen = set()
        unique_candidates = []
        for c in candidates:
            if c[0] not in seen:
                seen.add(c[0])
                unique_candidates.append(c)
        candidates = unique_candidates

        SCAN_STATUS["total"] = len(candidates)

        with closing(get_db()) as db:
            for i, (gallery_dir, category, _root_name) in enumerate(candidates):
                SCAN_STATUS["current"] = str(gallery_dir)
                SCAN_STATUS["scanned"] = i + 1

                result = scan_gallery(gallery_dir)
                if not result:
                    continue

                # 注入分类
                result["category"] = category or _root_name

                # upsert gallery
                cur = db.execute(
                    "SELECT id FROM galleries WHERE path = ?", (result["path"],)
                )
                row = cur.fetchone()
                if row:
                    gallery_id = row["id"]
                    db.execute("""
                        UPDATE galleries SET title=?, cover=?, page_count=?,
                            file_size=?, category=?, updated_at=CURRENT_TIMESTAMP
                        WHERE id=?
                    """, (result["title"], result["cover"], result["page_count"],
                          result["file_size"], result["category"], gallery_id))
                    # 清空旧图片，重新插入
                    db.execute("DELETE FROM gallery_images WHERE gallery_id=?", (gallery_id,))
                else:
                    cur = db.execute("""
                        INSERT INTO galleries (title, path, cover, page_count, file_size, category)
                        VALUES (?, ?, ?, ?, ?, ?)
                    """, (result["title"], result["path"], result["cover"],
                          result["page_count"], result["file_size"], result["category"]))
                    gallery_id = cur.lastrowid

                # 批量插入图片
                page_index = 0
                for img_path in result["images"]:
                    w, h = get_image_info(img_path)
                    db.execute("""
                        INSERT INTO gallery_images
                            (gallery_id, page_index, file_path, file_name, file_size, width, height)
                        VALUES (?, ?, ?, ?, ?, ?, ?)
                    """, (gallery_id, page_index, str(img_path), img_path.name,
                          img_path.stat().st_size, w, h))
                    page_index += 1

                db.commit()

                if progress_callback:
                    progress_callback(i + 1, len(candidates), str(gallery_dir))
    finally:
        SCAN_STATUS["running"] = False


# ============== API 路由 ==============

@app.route("/")
def index():
    """根路径返回 SPA 入口"""
    return send_from_directory(UI_DIR, "index.html")


@app.route("/<path:filename>")
def static_files(filename):
    """静态资源或 SPA fallback"""
    # 安全检查：防止路径穿越
    if ".." in filename or filename.startswith("/"):
        abort(404)

    # 静态文件存在则直接返回
    file_path = os.path.join(UI_DIR, filename)
    if os.path.isfile(file_path):
        return send_from_directory(UI_DIR, filename)

    # API 路径应该匹配上面的路由，这里不会走到

    # 其他路径：SPA fallback，返回 index.html 让前端路由处理
    # 这样可以支持 fnOS 在 url 模式下添加路径前缀
    return send_from_directory(UI_DIR, "index.html")


@app.route("/api/health")
def health():
    return jsonify({"ok": True, "version": "1.0.2"})


@app.route("/api/config", methods=["GET", "POST"])
def config():
    if request.method == "POST":
        new_cfg = request.get_json(force=True)
        cfg = load_config()
        cfg.update(new_cfg)
        with open(CONFIG_PATH, "w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)
        return jsonify({"ok": True, "config": cfg})
    return jsonify(load_config())


# ---------- 画廊 ----------
@app.route("/api/galleries", methods=["GET"])
def list_galleries():
    """画廊列表（支持搜索/筛选/排序/分页）"""
    keyword = request.args.get("q", "").strip()
    tags = request.args.getlist("tag")  # 多个 tag 参数
    favorite = request.args.get("favorite")  # "true"/"false"/None
    category = request.args.get("category", "").strip()  # 按分类筛选
    sort = request.args.get("sort", "updated_desc")  # updated_desc/created_desc/title_asc/page_desc/rating_desc
    page = int(request.args.get("page", 1))
    page_size = min(int(request.args.get("page_size", 24)), 100)

    where = []
    params = []

    if keyword:
        where.append("(g.id IN (SELECT rowid FROM galleries_fts WHERE galleries_fts MATCH ?))")
        params.append(f"{keyword}*")

    if favorite == "true":
        where.append("g.is_favorite = 1")

    if category:
        where.append("g.category = ?")
        params.append(category)

    if tags:
        # 包含所有指定 tag 的画廊
        for tag in tags:
            sub = """g.id IN (
                SELECT gt.gallery_id FROM gallery_tags gt
                JOIN tags t ON gt.tag_id = t.id
                WHERE t.name = ?
            )"""
            where.append(sub)
            params.append(tag)

    where_sql = ("WHERE " + " AND ".join(where)) if where else ""

    sort_map = {
        "updated_desc": "g.updated_at DESC",
        "created_desc": "g.created_at DESC",
        "title_asc": "g.title ASC",
        "title_desc": "g.title DESC",
        "page_desc": "g.page_count DESC",
        "page_asc": "g.page_count ASC",
        "rating_desc": "g.rating DESC",
        "favorite_first": "g.is_favorite DESC, g.updated_at DESC",
    }
    order_sql = f"ORDER BY {sort_map.get(sort, 'g.updated_at DESC')}"

    offset = (page - 1) * page_size

    with closing(get_db()) as db:
        total = db.execute(f"SELECT COUNT(*) AS c FROM galleries g {where_sql}", params).fetchone()["c"]
        rows = db.execute(f"""
            SELECT g.*,
                (SELECT GROUP_CONCAT(t.name, ',')
                 FROM gallery_tags gt JOIN tags t ON gt.tag_id = t.id
                 WHERE gt.gallery_id = g.id) AS tag_names
            FROM galleries g
            {where_sql}
            {order_sql}
            LIMIT ? OFFSET ?
        """, params + [page_size, offset]).fetchall()

        galleries = []
        for r in rows:
            galleries.append({
                "id": r["id"],
                "title": r["title"],
                "path": r["path"],
                "category": r["category"] or "",
                "cover": r["cover"],
                "page_count": r["page_count"],
                "file_size": r["file_size"],
                "description": r["description"],
                "rating": r["rating"],
                "view_count": r["view_count"],
                "is_favorite": bool(r["is_favorite"]),
                "last_read_page": r["last_read_page"],
                "last_read_at": r["last_read_at"],
                "created_at": r["created_at"],
                "updated_at": r["updated_at"],
                "tags": [t for t in (r["tag_names"] or "").split(",") if t],
            })

    return jsonify({
        "total": total,
        "page": page,
        "page_size": page_size,
        "items": galleries,
    })


@app.route("/api/categories")
def list_categories():
    """列出所有画廊分类（含每个分类的画廊数）"""
    with closing(get_db()) as db:
        rows = db.execute("""
            SELECT COALESCE(NULLIF(category, ''), '默认') AS name,
                   COUNT(*) AS count
            FROM galleries
            GROUP BY COALESCE(NULLIF(category, ''), '默认')
            ORDER BY name
        """).fetchall()
    return jsonify({
        "items": [dict(r) for r in rows],
        "total": len(rows),
    })


@app.route("/api/galleries/<int:gid>", methods=["GET"])
def get_gallery(gid):
    """画廊详情"""
    with closing(get_db()) as db:
        g = db.execute("SELECT * FROM galleries WHERE id = ?", (gid,)).fetchone()
        if not g:
            abort(404)
        # 增加浏览次数
        db.execute("UPDATE galleries SET view_count = view_count + 1 WHERE id = ?", (gid,))
        db.commit()

        # 标签
        tag_rows = db.execute("""
            SELECT t.id, t.name, t.color FROM tags t
            JOIN gallery_tags gt ON gt.tag_id = t.id
            WHERE gt.gallery_id = ?
        """, (gid,)).fetchall()

        # 图片列表
        img_rows = db.execute("""
            SELECT id, page_index, file_path, file_name, width, height
            FROM gallery_images
            WHERE gallery_id = ?
            ORDER BY page_index ASC
        """, (gid,)).fetchall()

    return jsonify({
        "id": g["id"],
        "title": g["title"],
        "path": g["path"],
        "cover": g["cover"],
        "page_count": g["page_count"],
        "file_size": g["file_size"],
        "description": g["description"],
        "rating": g["rating"],
        "view_count": g["view_count"],
        "is_favorite": bool(g["is_favorite"]),
        "last_read_page": g["last_read_page"],
        "last_read_at": g["last_read_at"],
        "created_at": g["created_at"],
        "updated_at": g["updated_at"],
        "tags": [{"id": t["id"], "name": t["name"], "color": t["color"]} for t in tag_rows],
        "images": [{
            "id": i["id"],
            "page_index": i["page_index"],
            "file_path": i["file_path"],
            "file_name": i["file_name"],
            "width": i["width"],
            "height": i["height"],
        } for i in img_rows],
    })


@app.route("/api/galleries/<int:gid>/favorite", methods=["POST"])
def toggle_favorite(gid):
    """切换收藏状态"""
    with closing(get_db()) as db:
        g = db.execute("SELECT is_favorite FROM galleries WHERE id = ?", (gid,)).fetchone()
        if not g:
            abort(404)
        new_state = 0 if g["is_favorite"] else 1
        db.execute("UPDATE galleries SET is_favorite = ? WHERE id = ?", (new_state, gid))
        db.commit()
    return jsonify({"ok": True, "is_favorite": bool(new_state)})


@app.route("/api/galleries/<int:gid>/progress", methods=["POST"])
def save_progress(gid):
    """保存阅读进度"""
    data = request.get_json(force=True)
    page = int(data.get("page", 0))
    with closing(get_db()) as db:
        db.execute("""
            UPDATE galleries SET last_read_page = ?, last_read_at = CURRENT_TIMESTAMP
            WHERE id = ?
        """, (page, gid))
        db.commit()
    return jsonify({"ok": True, "page": page})


@app.route("/api/galleries/<int:gid>/rating", methods=["POST"])
def set_rating(gid):
    """设置评分"""
    data = request.get_json(force=True)
    rating = float(data.get("rating", 0))
    rating = max(0, min(5, rating))
    with closing(get_db()) as db:
        db.execute("UPDATE galleries SET rating = ? WHERE id = ?", (rating, gid))
        db.commit()
    return jsonify({"ok": True, "rating": rating})


@app.route("/api/galleries/<int:gid>", methods=["DELETE"])
def delete_gallery(gid):
    """从数据库中删除画廊（不删除原文件）"""
    with closing(get_db()) as db:
        db.execute("DELETE FROM galleries WHERE id = ?", (gid,))
        db.commit()
    return jsonify({"ok": True})


# ---------- 标签 ----------
@app.route("/api/tags", methods=["GET"])
def list_tags():
    """所有标签"""
    with closing(get_db()) as db:
        rows = db.execute("""
            SELECT t.id, t.name, t.color, t.use_count, t.created_at
            FROM tags t
            ORDER BY t.use_count DESC, t.name ASC
        """).fetchall()
    return jsonify([dict(r) for r in rows])


@app.route("/api/tags", methods=["POST"])
def create_tag():
    """创建标签"""
    data = request.get_json(force=True)
    name = data.get("name", "").strip()
    color = data.get("color", "#1976d2")
    if not name:
        return jsonify({"ok": False, "error": "标签名不能为空"}), 400
    with closing(get_db()) as db:
        try:
            cur = db.execute("INSERT INTO tags (name, color) VALUES (?, ?)", (name, color))
            db.commit()
            return jsonify({"ok": True, "id": cur.lastrowid, "name": name, "color": color})
        except sqlite3.IntegrityError:
            return jsonify({"ok": False, "error": "标签已存在"}), 400


@app.route("/api/tags/<int:tid>", methods=["DELETE"])
def delete_tag(tid):
    with closing(get_db()) as db:
        db.execute("DELETE FROM tags WHERE id = ?", (tid,))
        db.commit()
    return jsonify({"ok": True})


@app.route("/api/galleries/<int:gid>/tags", methods=["POST"])
def add_tag_to_gallery(gid):
    """给画廊添加标签（标签不存在则自动创建）"""
    data = request.get_json(force=True)
    name = data.get("name", "").strip()
    if not name:
        return jsonify({"ok": False, "error": "标签名不能为空"}), 400

    with closing(get_db()) as db:
        # 找或建标签
        row = db.execute("SELECT id FROM tags WHERE name = ?", (name,)).fetchone()
        if row:
            tag_id = row["id"]
        else:
            cur = db.execute("INSERT INTO tags (name) VALUES (?)", (name,))
            tag_id = cur.lastrowid

        # 关联
        try:
            db.execute("INSERT INTO gallery_tags (gallery_id, tag_id) VALUES (?, ?)", (gid, tag_id))
            db.execute("UPDATE tags SET use_count = use_count + 1 WHERE id = ?", (tag_id,))
            db.commit()
            return jsonify({"ok": True, "tag_id": tag_id})
        except sqlite3.IntegrityError:
            return jsonify({"ok": True, "tag_id": tag_id, "exists": True})


@app.route("/api/galleries/<int:gid>/tags/<int:tid>", methods=["DELETE"])
def remove_tag_from_gallery(gid, tid):
    with closing(get_db()) as db:
        db.execute("DELETE FROM gallery_tags WHERE gallery_id = ? AND tag_id = ?", (gid, tid))
        db.execute("UPDATE tags SET use_count = MAX(0, use_count - 1) WHERE id = ?", (tid,))
        db.commit()
    return jsonify({"ok": True})


# ---------- 扫描 ----------
@app.route("/api/scan", methods=["POST"])
def trigger_scan():
    """触发扫描"""
    if SCAN_STATUS["running"]:
        return jsonify({"ok": False, "error": "扫描进行中"}), 409

    data = request.get_json(silent=True) or {}
    cfg = load_config()
    raw_scan_dirs = data.get("scan_dirs") or cfg.get("scan_dirs", [])

    # 诊断每个目录
    valid_dirs = []
    diagnostics = []
    for d in raw_scan_dirs:
        if not d:
            continue
        p = Path(d)
        if not p.exists():
            diagnostics.append({"path": d, "status": "not_found", "msg": "路径不存在"})
        elif not p.is_dir():
            diagnostics.append({"path": d, "status": "not_dir", "msg": "不是目录"})
        elif not os.access(str(p), os.R_OK):
            diagnostics.append({
                "path": d,
                "status": "no_permission",
                "msg": "无读取权限。请在 fnOS【应用设置】中为此应用授权访问该目录",
            })
        else:
            try:
                # 试图列举子目录
                subs = list(p.iterdir())
                valid_dirs.append(d)
                diagnostics.append({
                    "path": d,
                    "status": "ok",
                    "msg": f"可访问，包含 {len(subs)} 个项目",
                    "subdirs": len([s for s in subs if s.is_dir()]),
                })
            except PermissionError as e:
                diagnostics.append({
                    "path": d,
                    "status": "permission_error",
                    "msg": f"权限错误: {e}",
                })
            except Exception as e:
                diagnostics.append({
                    "path": d,
                    "status": "error",
                    "msg": f"扫描错误: {e}",
                })

    if not valid_dirs:
        return jsonify({
            "ok": False,
            "error": "没有可扫描的目录，请检查路径和权限",
            "diagnostics": diagnostics,
        }), 400

    def worker():
        with SCAN_LOCK:
            do_scan(valid_dirs)

    t = threading.Thread(target=worker, daemon=True)
    t.start()
    return jsonify({
        "ok": True,
        "scan_dirs": valid_dirs,
        "diagnostics": diagnostics,
    })


@app.route("/api/scan/status")
def scan_status():
    return jsonify(SCAN_STATUS)


@app.route("/api/scan/dirs", methods=["GET", "POST"])
def scan_dirs():
    cfg = load_config()
    if request.method == "POST":
        data = request.get_json(force=True)
        cfg["scan_dirs"] = data.get("scan_dirs", [])
        with open(CONFIG_PATH, "w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)
        return jsonify({"ok": True})
    return jsonify({"scan_dirs": cfg.get("scan_dirs", [])})


# ---------- 图片 / 缩略图 ----------
@app.route("/api/image")
def get_image():
    """获取原图（支持 quality 参数；动画 GIF/WebP 保留动画）"""
    fp = request.args.get("path")
    quality = request.args.get("quality", "high")
    if not fp or not os.path.exists(fp):
        abort(404)

    # 权限校验：必须是已扫描画廊内的图片
    with closing(get_db()) as db:
        row = db.execute("SELECT id FROM gallery_images WHERE file_path = ?", (fp,)).fetchone()
        if not row:
            abort(403)
        # 浏览计数：第一次访问图片时增加画廊 view_count
        db.execute("""
            UPDATE galleries SET view_count = view_count + 1
            WHERE id = (SELECT gallery_id FROM gallery_images WHERE id = ?)
        """, (row["id"],))
        db.commit()

    ext = Path(fp).suffix.lower()
    is_animated = False
    is_animation_ext = ext in (".gif", ".webp")

    # 检测是否为动画文件
    if is_animation_ext:
        try:
            with Image.open(fp) as im_check:
                is_animated = getattr(im_check, "is_animated", False) or getattr(im_check, "n_frames", 1) > 1
        except Exception:
            is_animated = False

    # 动画文件直接返回原文件（quality 强制 original）
    if is_animated:
        # 设置正确的 MIME
        mime = "image/gif" if ext == ".gif" else "image/webp"
        return send_file(fp, mimetype=mime)

    # quality 处理
    if quality == "original":
        mime = "image/gif" if ext == ".gif" else ("image/webp" if ext == ".webp" else None)
        return send_file(fp, mimetype=mime)

    # 压缩版本（仅静态图片）
    cache_dir = Path("/tmp/gallery_viewer_img_cache")
    cache_dir.mkdir(exist_ok=True, parents=True)
    cache_path = cache_dir / f"{hashlib.md5((fp + quality).encode()).hexdigest()[:16]}.jpg"

    if not cache_path.exists() or os.path.getmtime(cache_path) < os.path.getmtime(fp):
        try:
            with Image.open(fp) as im:
                im_rgb = im
                if im.mode in ("RGBA", "P"):
                    im_rgb = im.convert("RGB")
                if quality == "compressed":
                    im_rgb.save(cache_path, "JPEG", quality=70, optimize=True)
                else:  # high
                    im_rgb.save(cache_path, "JPEG", quality=88, optimize=True)
        except Exception as e:
            app.logger.error(f"图片处理失败 {fp}: {e}")
            return send_file(fp)

    return send_file(cache_path, mimetype="image/jpeg")


@app.route("/api/thumbnail")
def get_thumbnail():
    """获取缩略图（动画 GIF/WebP 保留动画）"""
    fp = request.args.get("path")
    size = int(request.args.get("size", 320))
    if not fp or not os.path.exists(fp):
        abort(404)

    # 权限校验
    with closing(get_db()) as db:
        row = db.execute("SELECT id FROM gallery_images WHERE file_path = ?", (fp,)).fetchone()
        if not row:
            abort(403)

    thumb_path = get_thumb_path(fp, size)
    make_thumbnail(fp, str(thumb_path), size=size)
    # 根据实际文件后缀返回正确 MIME（WebP/GIF 可能是 webp 容器）
    suffix = Path(str(thumb_path)).suffix.lower()
    mime = "image/webp" if suffix == ".webp" else "image/jpeg"
    return send_file(thumb_path, mimetype=mime)


@app.route("/api/cover")
def get_cover():
    """获取封面：动图也用静态第一帧（瀑布浏览避免视觉干扰）"""
    fp = request.args.get("path")
    if not fp or not os.path.exists(fp):
        abort(404)

    cfg = load_config()
    size = int(request.args.get("size", cfg.get("thumbnail_size", 320)))

    with closing(get_db()) as db:
        row = db.execute("SELECT id FROM gallery_images WHERE file_path = ?", (fp,)).fetchone()
        if not row:
            abort(403)

    thumb_path = get_thumb_path(fp, size)
    # 强制 .jpg 后缀（封面统一静态 JPEG）
    thumb_path = Path(str(thumb_path).rsplit(".", 1)[0] + ".jpg")
    make_thumbnail(fp, str(thumb_path), size=size, static_only=True)
    return send_file(str(thumb_path), mimetype="image/jpeg")


# ---------- 统计 ----------
@app.route("/api/stats")
def stats():
    """总体统计"""
    with closing(get_db()) as db:
        total = db.execute("SELECT COUNT(*) AS c FROM galleries").fetchone()["c"]
        total_pages = db.execute("SELECT SUM(page_count) AS c FROM galleries").fetchone()["c"] or 0
        total_size = db.execute("SELECT SUM(file_size) AS c FROM galleries").fetchone()["c"] or 0
        fav_count = db.execute("SELECT COUNT(*) AS c FROM galleries WHERE is_favorite=1").fetchone()["c"]
        tag_count = db.execute("SELECT COUNT(*) AS c FROM tags").fetchone()["c"]

        # 最近浏览
        recent = db.execute("""
            SELECT id, title, cover, last_read_at, last_read_page
            FROM galleries WHERE last_read_at IS NOT NULL
            ORDER BY last_read_at DESC LIMIT 10
        """).fetchall()

        # 最近添加
        recent_added = db.execute("""
            SELECT id, title, cover, page_count, created_at
            FROM galleries ORDER BY created_at DESC LIMIT 10
        """).fetchall()

    return jsonify({
        "total_galleries": total,
        "total_pages": total_pages,
        "total_size": total_size,
        "favorite_count": fav_count,
        "tag_count": tag_count,
        "recent_read": [dict(r) for r in recent],
        "recent_added": [dict(r) for r in recent_added],
    })


@app.errorhandler(404)
def not_found(e):
    return jsonify({"ok": False, "error": "not found"}), 404


@app.errorhandler(403)
def forbidden(e):
    return jsonify({"ok": False, "error": "forbidden"}), 403


# ============== 启动 ==============
if __name__ == "__main__":
    init_db()
    # 第一次启动时若有 scan_dirs 且数据库为空，自动扫描
    cfg = load_config()
    if cfg.get("scan_dirs") and cfg.get("auto_scan"):
        scan_dirs = [d for d in cfg["scan_dirs"] if os.path.isdir(d)]
        if scan_dirs:
            t = threading.Thread(target=do_scan, args=(scan_dirs,), daemon=True)
            t.start()
    print(f"[画廊浏览器] 启动于 http://{args.host}:{args.port}")
    app.run(host=args.host, port=args.port, threaded=True, debug=False)