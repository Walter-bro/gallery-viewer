# 画廊浏览器 Gallery Viewer

> 仿 EhViewer 设计的飞牛 fnOS 本地画廊浏览器 fpk 应用

## ✨ 核心特性

### 📚 画廊浏览核心
- **网格视图**：自适应瀑布流，缩略图快速扫览
- **列表视图**：含详细元数据的紧凑布局
- **Webtoon 式上下滚动阅读**（核心）：连续滚动、长条阅读、懒加载
- **单页/双页翻页模式**：支持横屏
- **双指缩放、键盘翻页、进度自动保存**

### 🔍 搜索与筛选
- **全文搜索**（FTS5）：标题 + 描述
- **标签云筛选**：点击标签快速筛选，支持多标签组合
- **高级排序**：最新更新/最新添加/标题 A-Z/页数/评分/收藏优先
- **仅收藏筛选**

### 🏷️ 收藏与标签系统
- **一键收藏** ⭐
- **自定义标签**：自由添加，标签自动翻译
- **标签使用次数统计**：自动按热度排序
- **收藏页 + 标签管理**：UI 直达

### 💾 其他
- **缩略图缓存**：内存缓存 + 磁盘缓存
- **图片质量切换**：原图/高质量/压缩
- **键盘快捷键**：← → 翻页，ESC 退出
- **完全本地**：隐私安全，无外网依赖

---

## 📦 安装方法

### 方法 1：上传 fpk 到 fnOS 应用中心
1. 登录飞牛 fnOS 管理后台
2. 进入「应用中心」→「手动安装」
3. 上传 `gallery-viewer.fpk` 文件
4. 按照向导完成配置

### 方法 2：SSH 安装
```bash
# 将 fpk 文件上传到 NAS
scp gallery-viewer.fpk root@your-nas-ip:/tmp/

# SSH 登录后安装
ssh root@your-nas-ip
appcenter-cli install-fpk /tmp/gallery-viewer.fpk
```

---

## 🛠️ 安装要求

- **fnOS 版本**：0.9.0 - 0.9.100
- **架构**：x86_64 / ARM（all）
- **依赖**：Python 3.12（应用中心会自动安装）
- **默认端口**：8899（可在向导中修改）

---

## 🎯 使用指南

### 第一步：扫描画廊
1. 安装完成后，打开应用
2. 进入「设置」→「扫描目录」，添加你的图片根目录
   - 例如：`/vol1/1000/Pictures`
   - 一级子文件夹会被视为独立画廊
3. 点击「开始扫描」
4. 等待扫描完成（进度可在弹窗中查看）

### 第二步：浏览画廊
- 在主界面浏览网格/列表视图
- 顶部搜索框输入关键字
- 左侧标签云点击筛选

### 第三步：阅读画廊
- 点击画廊卡片进入阅读
- 默认进入**上下滚动模式**（推荐）
- 顶部工具栏切换模式：
  - 📜 **上下滚动**：Webtoon 式，连续滚动阅读
  - ↔ **单页**：左右翻页
  - ⇄ **双页**：横屏双页阅读

### 第四步：收藏 + 标签
- 进入画廊后点击右上 ⭐ 收藏
- 点击「标签」按钮管理当前画廊标签
- 输入标签名按回车添加
- 标签可重复使用，自动计数

---

## 🏗️ 项目结构

```
gallery-viewer/
├── manifest                # 应用元信息
├── ICON.PNG                # 64x64 应用图标
├── ICON_256.PNG            # 256x256 应用图标
├── LICENSE                 # MIT 许可证
├── README.md               # 本文档
├── cmd/                    # 生命周期脚本
│   ├── main                # start/stop/status 主入口
│   ├── install_init        # 安装前钩子
│   ├── install_callback    # 安装后钩子（生成配置）
│   ├── uninstall_init      # 卸载前钩子
│   ├── upgrade_init        # 升级前钩子
│   ├── upgrade_callback    # 升级后钩子
│   ├── config_init         # 配置更新钩子
│   └── config_callback     # 配置应用钩子（重启）
├── config/
│   ├── privilege           # 权限配置（应用用户运行）
│   └── resource            # 资源配置（数据共享）
├── wizard/
│   ├── install             # 安装向导配置
│   ├── uninstall           # 卸载向导配置
│   └── config              # 配置向导
└── app/                    # 应用包内容（打包为 app.tgz）
    ├── ui/
    │   ├── config          # 应用入口配置
    │   └── images/         # UI 图标
    └── backend/
        ├── app.py          # Flask 后端
        ├── requirements.txt # Python 依赖
        └── static/         # 前端静态资源
            ├── index.html  # SPA 入口
            ├── css/app.css # 样式
            ├── js/app.js   # Vue 3 SPA
            ├── lib/        # Vue/Element Plus 静态资源
            └── favicon.svg
```

---

## 🛠️ 开发与重新打包

### 准备工具
```bash
# 下载 fnpack（推荐从 fnOS 开发者中心获取最新版本）
# https://developer.fnnas.com/docs/cli/fnpack
chmod +x fnpack
sudo mv fnpack /usr/local/bin/
```

### 修改代码后重新打包
```bash
# 1. 进入项目目录
cd gallery-viewer

# 2. 重新打包 app.tgz
rm -f app.tgz
tar -czf app.tgz app/

# 3. 用 fnpack build（推荐）或手动 tar 打包
fnpack build .

# 或者手动打包（不用 fnpack）：
tar -czf gallery-viewer.fpk \
  manifest ICON.PNG ICON_256.PNG \
  cmd/ config/ wizard/ app.tgz
```

### 本地开发测试
```bash
cd gallery-viewer
pip install Flask Flask-CORS Pillow

python3 app/backend/app.py \
  --host 0.0.0.0 \
  --port 8899 \
  --db ./dev.db \
  --config ./dev-config.json \
  --thumb-cache ./thumbs \
  --ui-dir ./app/backend/static
```

然后浏览器打开 `http://localhost:8899`。

---

## 🧱 技术栈

### 后端
- **Python 3.12**（fnOS 内置运行时）
- **Flask 3.0**：轻量 Web 框架
- **Pillow**：图片处理、缩略图生成
- **SQLite + FTS5**：本地数据库 + 全文搜索

### 前端
- **Vue 3.4**：渐进式前端框架（CDN 引入）
- **Element Plus 2.5**：UI 组件库
- **Element Plus Icons**：图标库
- **原生 CSS3**：响应式布局，深色模式适配

---

## 📜 关键设计决策

### 为什么是本地画廊管理（而非 E-Hentai 客户端）？
- 飞牛 fnOS 是 **NAS 系统**，核心场景是管理本地文件
- 本地画廊管理**完全合法合规**，无敏感内容问题
- 同时保留了 EhViewer 的核心交互体验

### 为什么用 Python + Flask？
- fnOS 内置 Python 3.12，无需打包运行时
- Flask 足够轻量，启动快、内存占用低
- 同步 IO + 简单并发，足以支撑本地访问

### 为什么 FTS5 用外部内容表（content='galleries'）？
- `content=''`（contentless）不支持 UPDATE/DELETE 触发器
- 外部内容表只索引不存储，更省空间
- 触发器必须用特殊语法：`INSERT INTO fts(fts, rowid, ...) VALUES('delete', ...)`

### 为什么 Webtoon 滚动模式是核心？
- 仿 EhViewer 的"竖屏连续阅读"是核心体验
- 适配 NAS 大屏展示（横屏）也方便
- 性能更好：图片懒加载、IntersectionObserver

---

## 🐛 已知问题

- 大目录扫描（> 1000 画廊）可能较慢，建议分批扫描
- ARM 架构下 Pillow 安装可能稍慢（首次启动约 30s）

---

## 📝 License

MIT License - 详见 [LICENSE](LICENSE) 文件

---

## 🙏 致谢

- **EhViewer**：核心交互设计灵感来源
- **Tachiyomi**：阅读器 UI 设计参考
- **飞牛 fnOS**：优秀的 NAS 系统平台
- **Element Plus**：出色的 Vue 3 组件库

---

## 反馈与贡献

如有问题或建议，欢迎在 fnOS 应用市场评论区留言。